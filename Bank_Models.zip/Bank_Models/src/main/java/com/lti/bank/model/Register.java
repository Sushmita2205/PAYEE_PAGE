package com.lti.bank.model;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="register")
public class Register {
 
	@Id
	@Column(name="customer_username")
	private String customerUsername;
	@Column(name="customer_password")
	private String customerPassword;
	@Column(name="transaction_password")
	private String transactionPassword;
	
	@JoinColumn(name="account_no")
	private int accountNo;
	
	@OneToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="customer_id")
	private Customer customer;
	
	public String getCustomerUsername() {
		return customerUsername;
	}
	public void setCustomerUsername(String customerUsername) {
		this.customerUsername = customerUsername;
	}
	public String getCustomerPassword() {
		return customerPassword;
	}
	public void setCustomerPassword(String customerPassword) {
		this.customerPassword = customerPassword;
	}
	public String getTransactionPassword() {
		return transactionPassword;
	}
	public void setTransactionPassword(String transactionPassword) {
		this.transactionPassword = transactionPassword;
	}
	public int getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(int accountNo) {
		this.accountNo = accountNo;
	}
	
	
	
	@Override
	public String toString() {
		return "Register [customerUsername=" + customerUsername + ", customerPassword=" + customerPassword
				+ ", transactionPassword=" + transactionPassword + ", accountNo=" + accountNo + ", customer=" + customer
				+ "]";
	}
	
	public Register(String customerUsername, String customerPassword, String transactionPassword, int accountNo) {
		super();
		this.customerUsername = customerUsername;
		this.customerPassword = customerPassword;
		this.transactionPassword = transactionPassword;
		this.accountNo = accountNo;
	}

	
	
	
	
}
