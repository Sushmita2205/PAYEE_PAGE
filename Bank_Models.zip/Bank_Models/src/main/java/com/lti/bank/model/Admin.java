package com.lti.bank.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="admin")
@SequenceGenerator(name = "seq3", sequenceName = "admin_sequence", allocationSize = 1, initialValue = 50440)
public class Admin {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seq3")
	@Column(name="admin_id")
	private int adminId;
	@Column(name="admin_password")
	private String adminPassword;
	
	@JoinColumn(name="branch_ifsc")
	private String branchIfsc;
	@JoinColumn(name="customer_username")
	private String customerUsername;
	public int getAdminId() {
		return adminId;
	}
	public void setAdminId(int adminId) {
		this.adminId = adminId;
	}
	public String getAdminPassword() {
		return adminPassword;
	}
	public void setAdminPassword(String adminPassword) {
		this.adminPassword = adminPassword;
	}
	public String getBranchIfsc() {
		return branchIfsc;
	}
	public void setBranchIfsc(String branchIfsc) {
		this.branchIfsc = branchIfsc;
	}
	public String getCustomerUsername() {
		return customerUsername;
	}
	public void setCustomerUsername(String customerUsername) {
		this.customerUsername = customerUsername;
	}
	public Admin(int adminId, String adminPassword, String branchIfsc, String customerUsername) {
		super();
		this.adminId = adminId;
		this.adminPassword = adminPassword;
		this.branchIfsc = branchIfsc;
		this.customerUsername = customerUsername;
	}
	@Override
	public String toString() {
		return "Admin [adminId=" + adminId + ", adminPassword=" + adminPassword + ", branchIfsc=" + branchIfsc
				+ ", customerUsername=" + customerUsername + "]";
	}
	
	
}
