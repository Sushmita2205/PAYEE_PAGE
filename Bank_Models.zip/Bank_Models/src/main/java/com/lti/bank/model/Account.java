package com.lti.bank.model;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@SequenceGenerator(name = "seq2", sequenceName = "account_no_sequence", allocationSize = 1, initialValue=678923450)
@Table(name="account")
public class Account {
	
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seq2")
	@Column(name="account_no")
	private long accountNo;
	@Column(name="account_services")
	private String accountServices;
	@Column(name="account_balue")
	private double accountBalance;
	@Column(name="account_type")
	private String accountType;

	@JoinColumn(name="branch_ifsc")
	private String branchIfsc;
	
	
	
	@ManyToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="customer_id")
	private Customer customer;
	
	
	@OneToMany(mappedBy="account")
	private List<Transactions> transactions;
	
	public Account() {
		super();
		
	}


	public long getAccountNo() {
		return accountNo;
	}


	public void setAccountNo(long accountNo) {
		this.accountNo = accountNo;
	}


	public String getAccountServices() {
		return accountServices;
	}


	public void setAccountServices(String accountServices) {
		this.accountServices = accountServices;
	}


	public double getAccountBalance() {
		return accountBalance;
	}


	public void setAccountBalance(double accountBalance) {
		this.accountBalance = accountBalance;
	}


	public String getAccountType() {
		return accountType;
	}


	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}


	public String getBranchIfsc() {
		return branchIfsc;
	}


	public void setBranchIfsc(String branchIfsc) {
		this.branchIfsc = branchIfsc;
	}




	@Override
	public String toString() {
		return "Account [accountNo=" + accountNo + ", accountServices=" + accountServices + ", accountBalance="
				+ accountBalance + ", accountType=" + accountType + ", branchIfsc=" + branchIfsc + ", customer="
				+ customer + "]";
	}


	public Account(long accountNo, String accountServices, double accountBalance, String accountType, String branchIfsc) {
		super();
		this.accountNo = accountNo;
		this.accountServices = accountServices;
		this.accountBalance = accountBalance;
		this.accountType = accountType;
		this.branchIfsc = branchIfsc;

	}


	
	
}
