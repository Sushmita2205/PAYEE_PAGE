package com.lti.bank.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="beneficiary")
public class Beneficiary {
	
	@Id
	@Column(name="beneficiary_account_no")
	private long beneficiaryAccountNo;
	@Column(name="beneficiary_name")
	private String benificiary_name;
	@Column(name="beneficiary_ifsc")
	private String beneficiary_ifsc;
	
	public Beneficiary() {
		super();
	}

	public long getBeneficiaryAccountNo() {
		return beneficiaryAccountNo;
	}

	public void setBeneficiaryAccountNo(long beneficiaryAccountNo) {
		this.beneficiaryAccountNo = beneficiaryAccountNo;
	}

	public String getBenificiary_name() {
		return benificiary_name;
	}

	public void setBenificiary_name(String benificiary_name) {
		this.benificiary_name = benificiary_name;
	}

	public String getBeneficiary_ifsc() {
		return beneficiary_ifsc;
	}

	public void setBeneficiary_ifsc(String beneficiary_ifsc) {
		this.beneficiary_ifsc = beneficiary_ifsc;
	}

	public Beneficiary(long beneficiaryAccountNo, String benificiary_name, String beneficiary_ifsc) {
		super();
		this.beneficiaryAccountNo = beneficiaryAccountNo;
		this.benificiary_name = benificiary_name;
		this.beneficiary_ifsc = beneficiary_ifsc;
	}

	@Override
	public String toString() {
		return "Beneficiary [beneficiaryAccountNo=" + beneficiaryAccountNo + ", benificiary_name=" + benificiary_name
				+ ", beneficiary_ifsc=" + beneficiary_ifsc + "]";
	}

	
}
