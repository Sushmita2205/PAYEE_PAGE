package com.lti.bank.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="rtgs_details")
@SequenceGenerator(name = "seq6", sequenceName = "imps_sequence", allocationSize = 1, initialValue = 90880)
public class IMPS {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seq6")
	@Column(name="imps_id")
	private int impsId;
	@Column(name="no_of_transactions")
	private int noOfTransactions;
	@Column(name="maturity_instructions")
	private String maturityInstructions;
	
	@JoinColumn(name="account_no")
	private long accountNo;
	@JoinColumn(name="beneficiary_account_no")
	private long beneficiaryAccountNo;
	public int getImpsId() {
		return impsId;
	}
	public void setImpsId(int impsId) {
		this.impsId = impsId;
	}
	public int getNoOfTransactions() {
		return noOfTransactions;
	}
	public void setNoOfTransactions(int noOfTransactions) {
		this.noOfTransactions = noOfTransactions;
	}
	public String getMaturityInstructions() {
		return maturityInstructions;
	}
	public void setMaturityInstructions(String maturityInstructions) {
		this.maturityInstructions = maturityInstructions;
	}
	public long getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(long accountNo) {
		this.accountNo = accountNo;
	}
	public long getBeneficiaryAccountNo() {
		return beneficiaryAccountNo;
	}
	public void setBeneficiaryAccountNo(long beneficiaryAccountNo) {
		this.beneficiaryAccountNo = beneficiaryAccountNo;
	}
	public IMPS(int impsId, int noOfTransactions, String maturityInstructions, long accountNo,
			long beneficiaryAccountNo) {
		super();
		this.impsId = impsId;
		this.noOfTransactions = noOfTransactions;
		this.maturityInstructions = maturityInstructions;
		this.accountNo = accountNo;
		this.beneficiaryAccountNo = beneficiaryAccountNo;
	}
	@Override
	public String toString() {
		return "IMPS [impsId=" + impsId + ", noOfTransactions=" + noOfTransactions + ", maturityInstructions="
				+ maturityInstructions + ", accountNo=" + accountNo + ", beneficiaryAccountNo=" + beneficiaryAccountNo
				+ "]";
	}
	
	
	
}
