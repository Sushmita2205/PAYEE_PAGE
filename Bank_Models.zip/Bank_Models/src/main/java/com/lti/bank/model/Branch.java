package com.lti.bank.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="branch")
public class Branch {
	
	@Id
	@Column(name="branch_ifsc")
	private String branchIfsc;
	@Column(name="branch_name")
	private String branchName;
	@Column(name="branch_location")
	private String branchLocation;
	@Column(name="branch_state")
	private String branchState;
	@Column(name="branch_city")
	private String branchCity;
	
	public Branch() {
		super();
	}

	public String getBranchIfsc() {
		return branchIfsc;
	}

	public void setBranchIfsc(String branchIfsc) {
		this.branchIfsc = branchIfsc;
	}

	public String getBranchName() {
		return branchName;
	}

	public void setBranchName(String branchName) {
		this.branchName = branchName;
	}

	public String getBranchLocation() {
		return branchLocation;
	}

	public void setBranchLocation(String branchLocation) {
		this.branchLocation = branchLocation;
	}

	public String getBranchState() {
		return branchState;
	}

	public void setBranchState(String branchState) {
		this.branchState = branchState;
	}

	public String getBranchCity() {
		return branchCity;
	}

	public void setBranchCity(String branchCity) {
		this.branchCity = branchCity;
	}

	@Override
	public String toString() {
		return "Branch [branchIfsc=" + branchIfsc + ", branchName=" + branchName + ", branchLocation=" + branchLocation
				+ ", branchState=" + branchState + ", branchCity=" + branchCity + "]";
	}

	public Branch(String branchIfsc, String branchName, String branchLocation, String branchState, String branchCity) {
		super();
		this.branchIfsc = branchIfsc;
		this.branchName = branchName;
		this.branchLocation = branchLocation;
		this.branchState = branchState;
		this.branchCity = branchCity;
	}

	
	
	

	
}
