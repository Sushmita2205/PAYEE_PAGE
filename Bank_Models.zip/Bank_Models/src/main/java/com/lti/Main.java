package com.lti;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.lti.bank.model.Customer;
import com.lti.utils.JpaUtils;

@SpringBootApplication
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 SpringApplication.run(Main.class, args);
		
		 EntityManager entityManager=JpaUtils.getEntityManager();
		
		 
		 Customer cust=new Customer();
		 cust.setCustomerName("JACK");
		 cust.setGender("male");
		 cust.setFatherName("bb");
		 cust.setMobileNo(7686954);
		 cust.setEmail("abc@gmail.com");
		 cust.setAdhaarNo(34466767);
		 cust.setPanNo("CEFSG688");
		 cust.setDateOfBirth("23/09/2020");
		 cust.setAddress("abc,nagar");
		 cust.setState("pune");
		 cust.setCity("thane");
		 cust.setPincode(45677788);
		 cust.setOccupationType("service");
		 cust.setAnnualIncome(57678.0);
		 entityManager.getTransaction().begin();
		 entityManager.persist(cust);
		 entityManager.getTransaction().commit();
		 

	}

}
